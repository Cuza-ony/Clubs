/**
 * JS page to add functionality to User Login/Register Page
 * After User successfully Logs in or creates an account they will go to user landing page
 */
$('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
});



