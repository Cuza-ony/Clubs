$(document).ready(function () {
	
	$('#login-form').submit(function(e) {
		alert(submitted);
	});
	
	$('#register-form').submit(function(e) {
		var username = $("#username").val();
		var first_name = $("#firstname").val();
		var last_name = $("#lastname").val();
		var gender = $("#gender").val();
		var year = $("#year").val();
		var username = $("#username").val();
		var password = $("#password").val();
		var email = $("#email").val();
		
	    if ($.trim($("#firstname", "#lastname", "#gender", "#year", "#email", "#username" ).val()) === "") {
	        e.preventDefault();
	        alert('you did not fill out one of the fields');
	    }
	    
	    $.ajax({ url: "Servlet", data: {firstname : first_name, lastname : last_name, gender : gender, 
			year : year, username : username, password : password, email : email}, success:validate});
	});
	
	
});

function validate(message){
	alert(message);
	
	if(mesage.equals("s"))
	{
		alert("made it");
		window.location.href ="http://localhost:8080/compilation/user.html";
	}
	$("#message").html(message);
	
	
}




