/**
 * JS page to add functionality to User Login/Register Page
 * After User successfully Logs in or creates an account they will go to user landing page
 */
"use strict";

$(document).ready(function () {
	$('.login-form').submit(function () {
		alert("Submitted loginform");
		var user_name = $("#user").val();
		var pass_word = $("#pass").val();
		$(function () {
			$.ajax({ url: "Servlet", data: {user : user_name, pass : pass_word}});
		});

	});
	
	$('#register-form').submit(function () {
		alert("Submitted");
		validate;
		var first_name = $("#firstname").val();
		alert(first_name);
		var last_name = $("#lastname").val();
		var gender = $("#gender").val();
		var year = $("#year").val();
		var username = $("#username").val();
		var password = $("#password").val();
		var email = $("#email").val();
		$(function () {
			$.ajax({ url: "Servlet", data: {firstname : first_name, lastname : last_name, gender : gender, 
				year : year, username : username, password : password, email : email}});
		});
	}); 

});


$('#username, #password, #genre, #year').bind('keyup', function() {
    if(allFilled()) $('#register').removeAttr('disabled');
});

function allFilled() {
    var filled = true;
    $('body input').each(function() {
        if($(this).val() == '') filled = false;
    });
    return filled;
}


function validate() {
	var first_name = $("#firstname").val();
	var last_name = $("#lastname").val();
	var gender = $("#gender").val();
	var year = $("#year").val();
	var username = $("#username").val();
	var password = $("#password").val();
	var email = $("#email").val(); 
	
    if (firstname === '') {
        alert("first is empty");
    } 
    if(lastname === '') {
        alert("last is empty");
    }
    
    if(username === '') {
        alert("username is empty");
    }
    if(password === '') {
        alert("password is empty");
    }

    
    
    else {
        alert("it is not an integer");
        return true;
    }
    return false; // this will disable the function
}

	
function showInterests(){
	value = ""; 
	window.alert("yes!!");
    valueParts = value.split("{.split}");
    //place html in there proper places on page
    $("#newArea").html(valueParts[0]);
    $("#currArea").html(valueParts[1]);
}